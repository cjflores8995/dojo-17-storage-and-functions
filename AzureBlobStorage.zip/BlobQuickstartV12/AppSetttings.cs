﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlobQuickstartV12
{
    public class AppSetttings
    {
        public string AzureStorageConnecionString { get; set; }
    }
}
